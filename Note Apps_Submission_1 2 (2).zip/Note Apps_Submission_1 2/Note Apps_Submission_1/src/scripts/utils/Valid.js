const validateForm = (formSelector, data) => {
  const formElement = document.querySelector(formSelector);
  let allValid = true;

  const validateOptions = [
    {
      attribute: "minlength",
      isValid: (input) =>
        input.value.length >= parseInt(input.getAttribute("minlength"), 10),
      errorMessage: (input, label) =>
        `${label.textContent} minimal ${input.getAttribute("minlength")} karakter`,
    },
    {
      attribute: "required",
      isValid: (input) => input.value.trim() !== "",
      errorMessage: (input, label) => `${label.textContent} tidak boleh kosong`,
    },
    {
      attribute: "pattern",
      isValid: (input) =>
        new RegExp(input.getAttribute("pattern")).test(input.value),
      errorMessage: (input, label) =>
        `Format ${label.textContent} tidak sesuai`,
    },
  ];

  const validateSingleFormGroup = (formGroup) => {
    const label = formGroup.querySelector("label");
    const input = formGroup.querySelector("input, textarea");
    const errorContainer = formGroup.querySelector(".error");

    let formGroupError = false;

    for (const option of validateOptions) {
      if (input.hasAttribute(option.attribute) && !option.isValid(input)) {
        errorContainer.textContent = option.errorMessage(input, label);
        input.classList.add("border-orange-500");
        input.classList.remove("border-purple-500");
        formGroupError = true;
      }
    }

    if (formGroupError) {
      allValid = false;
    }

    if (!formGroupError) {
      errorContainer.textContent = "";
      input.classList.remove("border-orange-500");
      input.classList.add("border-purple-500");
    }
  };

  formElement.setAttribute("novalidate", "");

  Array.from(formElement.elements).forEach((element) => {
    element.addEventListener("input", () => {
      validateSingleFormGroup(element.closest(".formGroup"));
    });
  });

  formElement.addEventListener("submit", (event) => {
    event.preventDefault();
    allValid = true;
    validateAllFormGroups(formElement);

    if (allValid) {
      const formData = new FormData(formElement);
      data(Object.fromEntries(formData));
    }
  });

  const validateAllFormGroups = (formToValidate) => {
    const formGroups = Array.from(
      formToValidate.querySelectorAll(".formGroup")
    );

    formGroups.forEach((formGroup) => {
      validateSingleFormGroup(formGroup);
    });
  };
};

export default validateForm;
