import { noteApi } from "../lib/axios";

export const GET_LIST_NOTE_NON_ARCHIVED = async () =>
  await noteApi.get("/notes");

export const GET_LIST_NOTE_ARCHIVED = async () =>
  await noteApi.get("/notes/archived");

export const POST_NOTE = async (payload) =>
  await noteApi.post("/notes", payload).then((res) => res.data);

export const POST_ARCHIVE_NOTE = async (id) =>
  await noteApi.post(`/notes/${id}/archive`);

export const POST_UNARCHIVE_NOTE = async (id) =>
  await noteApi.post(`/notes/${id}/unarchive`);

export const DELETE_NOTE = async (id) => await noteApi.delete(`/notes/${id}`);
