class TabsInformation extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
        <div class="grid max-w-[700px] gap-5 my-[20px] grid-cols-1 md:grid-cols-2 mx-auto place-content-around">
          <button class="nav-tabs__button non-archived active relative bg-[#A34343] py-[40px] px-[20px] rounded-md border-none text-white shadow-lg overflow-hidden">
            <i class="fa-solid fa-book-open absolute top-[30px] right-[20px] text-[150px] opacity-[0.2]"></i>
            <h2 class="font-bold">Belum Arsip</h2>
          </button>
          <button class="nav-tabs__button archived relative bg-[#A34343] py-[40px] px-[20px] rounded-md border-none text-white shadow-lg overflow-hidden">
            <i class="fa-solid fa-book absolute top-[30px] right-[20px] text-[150px] opacity-[0.2]"></i>
            <h2 class="font-bold">Arsip</h2>
          </button>
        </div>
      `;

    this.tabs();
  }

  // eslint-disable-next-line class-methods-use-this
  tabs() {
    const tabsButton = document.querySelectorAll(".nav-tabs__button");

    tabsButton.forEach((tab) => {
      tab.addEventListener("click", () => {
        tabsButton.forEach((tab) => {
          tab.classList.remove("active");
        });

        const listNote = document.querySelector("list-note");

        if (tab.className.split(" ").includes("archived")) {
          listNote.setAttribute("note-type", "archived");
        } else {
          listNote.setAttribute("note-type", "non-archived");
        }

        tab.classList.add("active");
      });
    });
  }
}

customElements.define("tabs-information", TabsInformation);
