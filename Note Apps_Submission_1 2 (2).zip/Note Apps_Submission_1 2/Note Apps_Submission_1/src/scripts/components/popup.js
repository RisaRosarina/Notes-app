const containerNote = document.querySelector(".container-note"),
popupNote = document.querySelector(".popup-note"),
closeNote = popupNote.querySelector("header i");

containerNote.addEventListener("click", () => {
    popupNote.classList.add("show");
});

closeNote.addEventListener("click", () => {
    popupNote.classList.remove ("show") ;
});

document.querySelector("#addNoteForm").addEventListener("submit", (event) => {
    event.preventDefault();
  
    popupNote.classList.remove("show");
});