class footerBox extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <footer class="text-center bg-[#496989] text-sm text-white p-[10px]">
        <p>
          Risa Rosarina, Note Apps &copy; 2024 
        </p>
      </footer>
    `;
  }
}

customElements.define("footer-box", footerBox);
