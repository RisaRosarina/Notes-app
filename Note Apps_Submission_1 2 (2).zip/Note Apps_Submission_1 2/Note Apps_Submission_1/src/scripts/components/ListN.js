import "./NoteI";
import {
  GET_LIST_NOTE_ARCHIVED,
  GET_LIST_NOTE_NON_ARCHIVED,
} from "../service/note.service";

class ListNote extends HTMLElement {
  constructor() {
    super();

    document.addEventListener("RENDER_LIST_NOTE", async () => {
      await this.connectedCallback();
    });
  }

  static get observedAttributes() {
    return ["note-type"];
  }

  async connectedCallback() {
    const noteType = this.getAttribute("note-type");

    try {
      this.#loading();

      let fetchNote;

      switch (noteType) {
        case "non-archived":
          fetchNote = await GET_LIST_NOTE_NON_ARCHIVED();
          break;
        case "archived":
          fetchNote = await GET_LIST_NOTE_ARCHIVED();
          break;
        default:
          return;
      }

      const { data } = fetchNote;

      this.innerHTML = "";
      this.render(data.data);
    } catch (error) {
      this.innerHTML = "";
      this.#error(error);
    }
  }

  render(notes) {
    if (notes.length === 0) {
      this.#notfound();
      return;
    }

    notes.forEach((note) => {
      const noteItem = document.createElement("note-item");
      noteItem.note = note;
      this.appendChild(noteItem);
    });

    const noteItems = this.querySelectorAll(".card");
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        entry.target.classList.toggle("show", entry.isIntersecting);
      });
    });

    noteItems.forEach((noteItem) => {
      observer.observe(noteItem);
    });
  }

  async attributeChangedCallback() {
    await this.connectedCallback();
  }

  #loading() {
    const cardLoading = document.createElement("card-loading");

    this.innerHTML = "";
    this.innerHTML += Array.from(
      { length: 5 },
      () => cardLoading.outerHTML
    ).join("");
  }

  #error(error) {
    this.innerHTML = `
      <div class="bg-red-400 text-white p-10 rounded-md">
        <span class="font-bold">Terjadi kesalahan:</span> ${error}
      </div>
    `;
  }

  #notfound() {
    this.innerHTML = `
      <div class="bg-red-400 text-center text-white p-10 rounded-md">
        <span class="font-bold">Catatan belum ada</span>
      </div>
    `;
  }
}

customElements.define("list-note", ListNote);
