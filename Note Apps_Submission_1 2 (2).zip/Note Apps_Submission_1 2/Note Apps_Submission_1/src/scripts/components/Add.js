import validateForm from "../utils/Valid";
import { POST_NOTE } from "../service/note.service";
import addLogo from "../../images/add.png";
import notepadLogo from "../../images/notepad.png";

class AddNoteForm extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `

    <div class="container-note">
    <h1><img src="${notepadLogo}" alt="" />Web Notes</h1>
      <div class="add-note">
      <button><img src="${addLogo}" alt="" />Buat Note Baru</button>
      </div>
  </div>
  
  <div class="popup-note">
  <div class="popup">
  <div class="content">
    <header>
      <h2 class="text-lg my-2 font-bold">
        Tambah Catatan
      </h2>
      <p class="cursor-pointer">
        <i class="fas fa-times"></i>
      </p>
    </header>
      <form id="addNoteForm">
        <div class="formGroup flex flex-col gap-2 my-4">
          <label for="title">Judul</label>
          <input 
            type="text"
            id="title" 
            name="title" 
            class="border p-2 rounded-md" 
            required
          >  
          <p class="error text-red-500 py-2"></p>
        </div>
        <div class="formGroup flex gap-2 flex-col my-4">
          <label for="body">Catatan</label>
          <textarea 
            id="body" 
            name="body"
            class="border p-2 rounded-md" 
            required
          ></textarea>
          <p class="error text-red-500 py-2"></p>
        </div>
        
        <button
          type="submit"
          class="bg-red-400 text-white p-2 rounded-md"
        >
          Simpan
        </button>
      </form>
    </div>
  </div>
</div>
    `;

    validateForm("#addNoteForm", async (data) => {
      const addNoteElement = this.querySelector("#addNoteForm");
      try {
        await POST_NOTE(data);

        addNoteElement.reset();

        Toastify({
          text: "Catatan berhasil ditambahkan",
          duration: 3000,
          close: true,
          gravity: "top",
          position: "right",
          backgroundColor: "#10B981",
          stopOnFocus: true,
        }).showToast();

        document.dispatchEvent(new CustomEvent("RENDER_LIST_NOTE"));
      } catch (error) {
        Toastify({
          text:
            error.response?.data.message ||
            error.message ||
            "Terjadi kesalahan",
          duration: 3000,
          close: true,
          gravity: "top",
          position: "right",
          backgroundColor: "#b91010",
          stopOnFocus: true,
        }).showToast();
      }
    });
  }
}

customElements.define("add-note-form", AddNoteForm);
