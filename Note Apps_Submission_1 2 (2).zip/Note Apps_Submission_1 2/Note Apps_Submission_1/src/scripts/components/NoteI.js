import {
  DELETE_NOTE,
  POST_ARCHIVE_NOTE,
  POST_UNARCHIVE_NOTE,
} from "../service/note.service";

class NoteItem extends HTMLElement {
  #note;

  set note(value) {
    this.#note = value;
    this.render();
  }

  render() {
    const { title, body, createdAt, archived } = this.#note;

    this.innerHTML = `
      <div class="border card hover:shadow-xl transform translate-x-[100px] opacity-0 transition p-3 rounded-md ${archived ? "bg-orange-200" : "bg-red-200"}">
        <h2 class="text-lg font-bold">${title}</h2>
        <span class="block my-1 text-sm text-gray-400">
          ${archived ? "Arsip" : "Belum Arsip"}
        </span>
        <p class="text-sm text-gray-500">${new Date(createdAt).toLocaleString()}</p>
        <p class="my-2 text-sm text-wrap break-all ">${body}</p>
        <div>
          <button
           class="p-3 action-move rounded bg-orange-300 hover:bg-orange-200">
            ${archived ? "Non Arsipkan" : "Arsipkan"}
          </button>
          <button class="p-3 action-delete rounded bg-red-300 hover:bg-red-200">
            Hapus
          </button>
        </div>
        
      </div>
    `;

    const actionMove = this.querySelector(".action-move");
    const actionDelete = this.querySelector(".action-delete");

    actionMove.addEventListener("click", async () => {
      await this.actionNote(archived, this.#note.id);
    });

    actionDelete.addEventListener("click", async () => {
      await this.actionDelete(this.#note.id);
    });
  }

  // eslint-disable-next-line class-methods-use-this
  async actionNote(isArchived, id) {
    try {
      if (isArchived) {
        await POST_UNARCHIVE_NOTE(id);
      } else {
        await POST_ARCHIVE_NOTE(id);
      }

      Toastify({
        text: "Catatan berhasil dipinahkan",
        duration: 3000,
        close: true,
        gravity: "top",
        position: "right",
        backgroundColor: "#10B981",
        stopOnFocus: true,
      }).showToast();

      document.dispatchEvent(new CustomEvent("RENDER_LIST_NOTE"));
    } catch (error) {
      Toastify({
        text:
          error.response?.data.message || error.message || "Terjadi kesalahan",
        duration: 3000,
        close: true,
        gravity: "top",
        position: "right",
        backgroundColor: "#b91010",
        stopOnFocus: true,
      }).showToast();
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async actionDelete(id) {
    try {
      await DELETE_NOTE(id);
      Toastify({
        text: "Catatan berhasil dihapus",
        duration: 3000,
        close: true,
        gravity: "top",
        position: "right",
        backgroundColor: "#10B981",
        stopOnFocus: true,
      }).showToast();
      document.dispatchEvent(new CustomEvent("RENDER_LIST_NOTE"));
    } catch (error) {
      Toastify({
        text:
          error.response?.data.message || error.message || "Terjadi kesalahan",
        duration: 3000,
        close: true,
        gravity: "top",
        position: "right",
        backgroundColor: "#b91010",
        stopOnFocus: true,
      }).showToast();
    }
  }
}

customElements.define("note-item", NoteItem);
