import logo from "../../images/logo.png";

class headerBox extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
        <header class="bg-[#496989] p-[20px]">
          <img src="${logo}">
        </header>
      `;
  }
}

customElements.define("header-box", headerBox);
