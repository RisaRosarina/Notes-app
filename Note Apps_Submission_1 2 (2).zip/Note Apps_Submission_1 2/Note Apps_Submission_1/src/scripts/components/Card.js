class CardLoading extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <div class="p-2">
        <div class="animate-pulse bg-[#f0f0f0] p-[20px] rounded-md border-none shadow-lg overflow-hidden">
          <div class="h-[20px] w-[80%] bg-[#e0e0e0] rounded-md mb-[10px]"></div>
          <div class="h-[20px] w-[60%] bg-[#e0e0e0] rounded-md mb-[10px]"></div>
          <div class="h-[20px] w-[40%] bg-[#e0e0e0] rounded-md mb-[10px]"></div>
        </div>
      </div>
    `;
  }
}

customElements.define("card-loading", CardLoading);
