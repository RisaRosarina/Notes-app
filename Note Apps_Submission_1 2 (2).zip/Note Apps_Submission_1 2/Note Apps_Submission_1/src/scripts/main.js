import "regenerator-runtime";
import "./components/Add";
import "./components/Card";
import "./components/footer";
import "./components/header";
import "./components/ListN";
import "./components/popup";
import "./components/TabInf";
import "../styles/style.css";

const app = () => {
  const listNote = document.querySelector("list-note");
  const dataInformationContainer = document.querySelector(
    ".information-container"
  );
  const dataInformation = document.createElement("tabs-information");

  dataInformationContainer.appendChild(dataInformation);

  listNote.className = "max-w-[700px] mx-auto my-5 grid gap-5";
};

document.addEventListener("DOMContentLoaded", app);
